﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using ContosoUniversity.Data;
using ContosoUniversity.Models;

namespace ContosoUniversity.PagesStudents
{
    public class CreateModel : PageModel
    {
        private readonly ContosoUniversity.Data.SchoolContext _context;

        public CreateModel(ContosoUniversity.Data.SchoolContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public Student Student { get; set; }




        // down below is an overposting example- unable to get it to work


      //  public class Student
      //  {
      //      public int ID { get; set; }
      //      public string LastName { get; set; }
      //      public string FirstMidName { get; set; }
      //      public DateTime EnrollmentDate { get; set; }
      //      public string Secret { get; set; }
      //  }
  
    
  
     
        //    public class StudentVM
        //    {
        //        public int ID { get; set; }
        //        public string LastName { get; set; }
        //        public string FirstMidName { get; set; }
        //        public DateTime EnrollmentDate { get; set; }
        //    }



        //   [BindProperty]
        //   public StudentVM StudentVM { get; set; }
        //
        //   public async Task<IActionResult> OnPostAsync()
        //   {
        //       if (!ModelState.IsValid)
        //       {
        //           return Page();
        //       }
        //
        //       var entry = _context.Add(new Student());
        //       entry.CurrentValues.SetValues(StudentVM);
        //       await _context.SaveChangesAsync();
        //       return RedirectToPage("./Index");
        //   }
        //
        //



        // This method helps with overposting attacks- 
        // tryupdate model updates fields with posted values- is the best security practice bc it prevents overposting
        public async Task<IActionResult> OnPostAsync()
            {
                var emptyStudent = new Student();
            
                if (await TryUpdateModelAsync<Student>(
                    emptyStudent,
                    "student",   // Prefix for form value.
                    s => s.FirstMidName, s => s.LastName, s => s.EnrollmentDate))
                {
                    _context.Students.Add(emptyStudent);
                    await _context.SaveChangesAsync();
                    return RedirectToPage("./Index");
                }
            
                return Page();
            }
    }
}
